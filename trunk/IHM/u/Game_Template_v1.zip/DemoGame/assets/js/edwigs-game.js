/**
 * file: edwigs-game.js
 * version: 0.1
 */